#pragma once
#include "Gameobject.h"
using namespace std;
class Food : public GameObject {
	int count;
public:
	Food(int starX, int starY, int dis) : GameObject(starX, starY, dis) {
		srand((unsigned)time(0));
		count = 0;
	}
	void move();
	char getShape();

};