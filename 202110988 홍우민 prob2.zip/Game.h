#pragma once
#include "Human.h"
#include "Monster.h"
#include "Food.h"
#include "Gameobject.h"
#include <iostream>
using namespace std;

class Game {
public:
	void game();


};