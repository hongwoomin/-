#include <iostream>
#include "Game.h"
using namespace std;
int main() {
	Game* g = new Game;
	g->game();
	delete g;
}