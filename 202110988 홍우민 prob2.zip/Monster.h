#pragma once
#include "Gameobject.h"
using namespace std;

class Monster : public GameObject {
public:
	Monster(int starX, int starY, int dis) : GameObject(starX, starY, dis) {
		srand((unsigned)time(0));
	}
	void move();

	char getShape();

};