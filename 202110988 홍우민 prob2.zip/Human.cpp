#include "Human.h"
using namespace std;
void Human::move() {
	char key;
	cout << "����(a), �Ʒ�(s), ��(d), ������(f) >> ";
	cin >> key;
	cout << endl;
	if (key == 'a') {
		if (y - distance < 0) y = 20 + y - distance;
		else y -= distance;
	}
	else if (key == 's') {
		if (x + distance > 9) x = x + distance - 10;
		else x += distance;
	}
	else if (key == 'd') {
		if (x - distance < 0) x = 10 + x - distance;
		else x -= distance;
	}
	else if (key == 'f') {
		if (y + distance > 19) y = y + distance - 20;
		else y += distance;
	}
}
char Human::getShape() {
	return 'H';
}