#pragma once
#include "Gameobject.h"
#include <iostream>
using namespace std;
class Human : public GameObject {
public:
	Human(int starX, int starY, int dis) : GameObject(starX, starY, dis) { ; }
	void move();
	char getShape();
};
