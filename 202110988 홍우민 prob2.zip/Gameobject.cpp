#include "Gameobject.h"


bool GameObject::collide(GameObject* p) {
	if (this->x == p->getX() && this->y == p->getY())
		return true;
	else
		return false;
}